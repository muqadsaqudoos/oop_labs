class Timespan:
    def __init__(self,hours,minutes):

        self.hours = hours
        self.minutes = minutes

    def show(self):

        print(f"{self.hours} hours and {self.minutes} minutes") 
    
    def add_hours(self,hr):

        self.hours += hr

    def add_minutes(self,min):

        self.hours += min//60
        self.minutes += min*60

        

    def change(self,ts):
        h = abs(self.hours - ts.hours)
        m = abs(self.minutes - ts.minutes)
        total_minutes = h *60+m
        return total_minutes
    
def main():
    a = Timespan(4,5)
    a.show()
    a.add_hours(3)
    a.add_minutes(60)
    a.show()
    b = Timespan(9,10)
    c = Timespan(4,5)
    
    print(b.change(c))
main()