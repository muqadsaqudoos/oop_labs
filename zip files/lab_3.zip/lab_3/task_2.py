class Timespan:
    def __init__(self,minutes):
        self.minutes = minutes

    def show(self):
        hours = self.minutes//60
        minutes = self.minutes%60
        print(f"{hours} hours and {minutes} minutes") 
    
    def add_hours(self,hr):

        self.minutes += hr*60

    def add_minutes(self,min):

        self.minutes += min

        

    def change(self,ts):
        m = abs(self.minutes-ts.minutes)
        return m
    
def main():
    a = Timespan(310)
    a.show()
    a.add_hours(3)
    a.add_minutes(60)
    a.show()
    b = Timespan(200)
    c = Timespan(400)
    
    print(b.change(c))
main()